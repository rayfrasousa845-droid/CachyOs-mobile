# CachyOS Launcher (Android)

Seu desktop CachyOS/Plasma simulado, agora como launcher de verdade.

## Como gerar o APK
1. Abra esta pasta no Android Studio (Koala ou mais novo). Ele baixa o Gradle e as dependências sozinho.
2. Run ▶ no celular (depuração USB ligada) ou Build > Build APK(s).
3. Depois de instalar, aperte Início e escolha "CachyOS Launcher" > Sempre.
   (ou Ajustes > Apps > Apps padrão > App de tela inicial)

## O que é real
- Menu, área de trabalho e barra de tarefas mostram os apps instalados, com ícones reais.
- Jogos: apps detectados como jogo pelo Android + os que você marcar manualmente.
- Terminal: shell /system/bin/sh de verdade (sem root). Prompt com a pasta atual, Tab completa, ↑/↓ histórico (salvo), Ctrl+C / botão ^C interrompe, cores ANSI, código de saída e barra de teclas para o celular. Comandos extras: apps, launch, mangohud <app>, history.
- Monitor: RAM, bateria, temperatura, clock da CPU e GPU (quando o aparelho deixa ler).
- Overlay "MangoHud": FPS/RAM/CPU/GPU/bateria por cima do jogo.

## Limites
- MangoHud original é Linux (Vulkan/OpenGL). Não roda em jogos Android; o overlay aqui é uma imitação.
- FPS real do jogo: `adb shell pm grant com.cachyos.launcher android.permission.DUMP` (depende do aparelho).
  Sem isso o overlay mostra a taxa de atualização da tela.
- Sem root, o terminal roda com as permissões do app.
- Os apps simulados (Cobrinha, Pacotes, Kernel, Wine...) continuam sendo só visual.
