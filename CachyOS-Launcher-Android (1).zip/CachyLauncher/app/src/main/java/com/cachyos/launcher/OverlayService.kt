package com.cachyos.launcher

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/** Overlay estilo MangoHud: FPS, CPU, GPU, RAM e bateria por cima do jogo. */
class OverlayService : Service() {
    companion object {
        fun start(c: Context, pkg: String) {
            c.startForegroundService(Intent(c, OverlayService::class.java).putExtra("pkg", pkg))
        }
        fun stop(c: Context) { c.stopService(Intent(c, OverlayService::class.java)) }
    }

    private var wm: WindowManager? = null
    private var tv: TextView? = null
    private val ui = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var bg: Handler? = null
    private var pkg = ""
    private var layer: String? = null
    private var layerAt = 0L
    private var dumpOk = true
    private var frames = 0
    private var running = false

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) { frames++; if (running) Choreographer.getInstance().postFrameCallback(this) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        pkg = i?.getStringExtra("pkg") ?: ""
        layer = null; dumpOk = true
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mh", "Overlay de desempenho", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "mh").setContentTitle("Overlay MangoHud ativo")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (tv == null) build()
        if (!running) {
            running = true
            worker = HandlerThread("mh-worker").also { it.start() }
            bg = Handler(worker!!.looper)
            Choreographer.getInstance().postFrameCallback(frameCb)
            ui.post(tick)
        }
        return START_NOT_STICKY
    }

    private fun prefs() = getSharedPreferences("mh", MODE_PRIVATE)

    private fun build() {
        val p = prefs()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val t = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            setTextColor(Color.WHITE)
            setBackgroundColor(0x99000000.toInt())
            setPadding(14, 8, 14, 8)
            setShadowLayer(2f, 1f, 1f, Color.BLACK)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, p.getInt("size", 12).toFloat())
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = if (p.getString("pos", "tl") == "tr") Gravity.TOP or Gravity.END else Gravity.TOP or Gravity.START
        lp.x = 12; lp.y = 48
        wm!!.addView(t, lp)
        tv = t
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val hz = frames; frames = 0
            bg?.post {
                val text = compose(hz)
                ui.post { tv?.text = text }
            }
            ui.postDelayed(this, 1000)
        }
    }

    private fun compose(hz: Int): String {
        val p = prefs()
        val sb = StringBuilder()
        if (p.getBoolean("fps", true)) {
            val g = if (pkg.isNotEmpty() && dumpOk) gameFps() else null
            sb.append(if (g != null) "FPS  %.0f  (%.1f ms)\n".format(g, 1000f / maxOf(g, 1f)) else "TELA %d Hz\n".format(hz))
        }
        if (p.getBoolean("cpu", true)) {
            val c = Stats.cpuMhz().filter { it > 0 }
            if (c.isNotEmpty()) sb.append("CPU  %.2f GHz\n".format(c.max() / 1000f))
        }
        if (p.getBoolean("gpu", true)) {
            val g = Stats.gpuPct()
            if (g >= 0) sb.append("GPU  $g%\n")
        }
        if (p.getBoolean("ram", true)) {
            val mi = ActivityManager.MemoryInfo()
            getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
            sb.append("RAM  %.1f/%.1f GB\n".format((mi.totalMem - mi.availMem) / 1073741824f, mi.totalMem / 1073741824f))
        }
        if (p.getBoolean("bat", true)) {
            val b = Stats.battery(this)
            sb.append("BAT  %d%%  %.1f°C  %.1fW%s".format(b.pct, b.tempC, b.watts, if (b.charging) " ⚡" else ""))
        }
        return sb.toString().trimEnd()
    }

    /** FPS real do jogo via dumpsys SurfaceFlinger. Só funciona com a permissão DUMP concedida por adb. */
    private fun gameFps(): Float? {
        val now = System.currentTimeMillis()
        if (layer == null && now - layerAt > 3000) {
            layerAt = now
            val out = Stats.sh("dumpsys SurfaceFlinger --list")
            if (out.isBlank() || out.contains("Permission", true) || out.contains("denied", true)) { dumpOk = false; return null }
            val l = out.lines().map { it.trim() }.filter { it.contains(pkg) && !it.startsWith("Background") && !it.startsWith("Bounds") }
            layer = l.firstOrNull { it.startsWith("SurfaceView") } ?: l.firstOrNull()
        }
        val ly = layer ?: return null
        val rows = Stats.sh("dumpsys SurfaceFlinger --latency \"$ly\"").lines().drop(1)
        val ts = rows.mapNotNull { r ->
            val c = r.trim().split(Regex("\\s+"))
            if (c.size >= 3) c[1].toLongOrNull() else null
        }.filter { it > 0 && it < Long.MAX_VALUE }
        if (ts.size < 2) { layer = null; return null }
        val last = ts.max()
        val recent = ts.filter { last - it <= 1_000_000_000L }
        if (recent.size < 2) return 0f
        return (recent.size - 1) * 1e9f / (recent.max() - recent.min())
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        Choreographer.getInstance().removeFrameCallback(frameCb)
        try { tv?.let { wm?.removeView(it) } } catch (_: Exception) {}
        tv = null
        worker?.quitSafely()
        super.onDestroy()
    }
}
