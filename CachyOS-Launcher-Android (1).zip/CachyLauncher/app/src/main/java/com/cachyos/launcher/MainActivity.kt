package com.cachyos.launcher

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : Activity() {
    lateinit var web: WebView
    lateinit var shell: Shell
    private lateinit var bridge: Bridge

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#16191C")
        window.navigationBarColor = Color.parseColor("#16191C")

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0B0B18"))
        setContentView(web)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/icon/", IconHandler(this))
            .build()

        shell = Shell(this) { chunk ->
            web.post { web.evaluateJavascript("window.__shellOut&&__shellOut(" + JSONObject.quote(chunk) + ")", null) }
        }
        bridge = Bridge(this)

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                bridge.armed = true // libera o token uma única vez para a página principal
            }
        }
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
        }
        web.addJavascriptInterface(bridge, "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    // Apertar Início com o launcher já aberto: minimiza as janelas
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) web.evaluateJavascript("window.__home&&__home()", null)
    }

    // Voltar fecha a janela de cima (um launcher nunca sai)
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.__back&&__back()", null)
    }

    override fun onDestroy() {
        shell.stop()
        super.onDestroy()
    }
}
