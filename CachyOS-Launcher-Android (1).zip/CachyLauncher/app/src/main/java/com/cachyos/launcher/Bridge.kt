package com.cachyos.launcher

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.app.role.RoleManager
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.provider.Settings
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Ponte JS -> Android. Todo método exige o token, entregue uma única vez à página principal
 * (init). Assim iframes (jogos .html, navegador) não conseguem chamar o shell nem lançar apps.
 */
class Bridge(private val a: MainActivity) {
    private val token = UUID.randomUUID().toString()
    @Volatile var armed = true

    private fun prefs() = a.getSharedPreferences("mh", Context.MODE_PRIVATE)
    private fun ui(f: () -> Unit) = a.runOnUiThread { try { f() } catch (_: Exception) {} }

    @JavascriptInterface
    fun init(): String { if (!armed) return ""; armed = false; return token }

    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun apps(t: String): String {
        if (t != token) return "[]"
        val pm = a.packageManager
        val arr = JSONArray()
        val seen = HashSet<String>()
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        for (r in pm.queryIntentActivities(q, 0)) {
            val ai = r.activityInfo.applicationInfo
            if (ai.packageName == a.packageName || !seen.add(ai.packageName)) continue
            val game = (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 || ai.category == ApplicationInfo.CATEGORY_GAME
            arr.put(JSONObject().put("p", ai.packageName).put("n", r.loadLabel(pm).toString()).put("g", game))
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun launch(t: String, pkg: String, overlay: Boolean): String {
        if (t != token) return "denied"
        val i = a.packageManager.getLaunchIntentForPackage(pkg) ?: return "Esse app não tem tela inicial."
        if (overlay) {
            if (!Settings.canDrawOverlays(a)) return "perm"
            OverlayService.start(a, pkg)
        } else OverlayService.stop(a)
        ui { a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        return "ok"
    }

    @JavascriptInterface
    fun overlay(t: String, on: Boolean, pkg: String) {
        if (t != token) return
        if (on && Settings.canDrawOverlays(a)) OverlayService.start(a, pkg) else OverlayService.stop(a)
    }

    @JavascriptInterface
    fun canOverlay(t: String): Boolean = t == token && Settings.canDrawOverlays(a)

    @JavascriptInterface
    fun askOverlay(t: String) {
        if (t != token) return
        ui { a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + a.packageName))) }
    }

    @JavascriptInterface
    fun appInfo(t: String, pkg: String) {
        if (t != token) return
        ui { a.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) }
    }

    @JavascriptInterface
    fun uninstall(t: String, pkg: String) {
        if (t != token) return
        ui { a.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))) }
    }

    @JavascriptInterface
    fun homeSettings(t: String) {
        if (t != token) return
        ui { a.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
    }

    /** Launchers instalados (apps que respondem ao botão Início) e qual é o padrão agora. */
    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun launchers(t: String): String {
        if (t != token) return "[]"
        val pm = a.packageManager
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val cur = pm.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
        val arr = JSONArray()
        val seen = HashSet<String>()
        for (r in pm.queryIntentActivities(home, 0)) {
            val p = r.activityInfo.packageName
            if (!seen.add(p)) continue
            arr.put(JSONObject().put("p", p).put("n", r.loadLabel(pm).toString())
                .put("me", p == a.packageName).put("d", p == cur))
        }
        return arr.toString()
    }

    /** Abre outro launcher só desta vez (o padrão continua o mesmo). */
    @Suppress("DEPRECATION")
    @JavascriptInterface
    fun openLauncher(t: String, pkg: String): String {
        if (t != token) return "denied"
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).setPackage(pkg)
        val ri = a.packageManager.queryIntentActivities(q, 0).firstOrNull() ?: return "Launcher não encontrado."
        ui {
            a.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        return "ok"
    }

    /** Pede ao Android para tornar este app o launcher padrão (diálogo direto no Android 10+). */
    @JavascriptInterface
    fun setDefault(t: String) {
        if (t != token) return
        ui {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = a.getSystemService(RoleManager::class.java)
                if (rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    a.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 1)
                    return@ui
                }
            }
            a.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        }
    }

    @JavascriptInterface
    fun settings(t: String) {
        if (t != token) return
        ui { a.startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    @JavascriptInterface
    fun cfgGet(t: String): String {
        if (t != token) return "{}"
        val p = prefs()
        return JSONObject().put("fps", p.getBoolean("fps", true)).put("cpu", p.getBoolean("cpu", true))
            .put("gpu", p.getBoolean("gpu", true)).put("ram", p.getBoolean("ram", true))
            .put("bat", p.getBoolean("bat", true)).put("pos", p.getString("pos", "tl"))
            .put("size", p.getInt("size", 12)).toString()
    }

    @JavascriptInterface
    fun cfgSet(t: String, json: String) {
        if (t != token) return
        val j = JSONObject(json)
        prefs().edit()
            .putBoolean("fps", j.optBoolean("fps", true)).putBoolean("cpu", j.optBoolean("cpu", true))
            .putBoolean("gpu", j.optBoolean("gpu", true)).putBoolean("ram", j.optBoolean("ram", true))
            .putBoolean("bat", j.optBoolean("bat", true))
            .putString("pos", if (j.optString("pos") == "tr") "tr" else "tl")
            .putInt("size", j.optInt("size", 12).coerceIn(8, 24)).apply()
    }

    @JavascriptInterface
    fun sysinfo(t: String): String {
        if (t != token) return "{}"
        val mi = ActivityManager.MemoryInfo()
        a.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val b = Stats.battery(a)
        return JSONObject().put("ramT", mi.totalMem).put("ramA", mi.availMem)
            .put("cpu", JSONArray(Stats.cpuMhz())).put("gpu", Stats.gpuPct())
            .put("bat", b.pct).put("temp", b.tempC.toDouble()).put("w", b.watts.toDouble())
            .put("chg", b.charging).toString()
    }

    @JavascriptInterface fun shellStart(t: String) { if (t == token) Thread { a.shell.start() }.start() }
    @JavascriptInterface fun shellWrite(t: String, s: String) { if (t == token) a.shell.write(s) }
    @JavascriptInterface fun shellStop(t: String) { if (t == token) a.shell.stop() }
}
