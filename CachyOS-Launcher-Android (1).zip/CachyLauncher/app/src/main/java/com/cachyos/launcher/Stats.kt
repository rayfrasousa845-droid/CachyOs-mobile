package com.cachyos.launcher

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.math.abs

object Stats {
    data class Bat(val pct: Int, val tempC: Float, val watts: Float, val charging: Boolean)

    private fun read(p: String): String? = try { File(p).readText().trim() } catch (e: Exception) { null }

    /** MHz por núcleo (-1 quando o aparelho bloqueia a leitura). */
    fun cpuMhz(): List<Int> = (0 until Runtime.getRuntime().availableProcessors()).map { i ->
        read("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq")?.toLongOrNull()?.div(1000)?.toInt() ?: -1
    }

    /** Uso da GPU em % (só Adreno/alguns Mali que liberam leitura), -1 se indisponível. */
    fun gpuPct(): Int {
        for (p in listOf("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage", "/sys/class/kgsl/kgsl-3d0/devfreq/gpu_load")) {
            read(p)?.filter { it.isDigit() }?.toIntOrNull()?.let { return it }
        }
        return -1
    }

    fun battery(c: Context): Bat {
        val i: Intent? = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val ua = c.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val amps = if (abs(ua) > 20000) abs(ua) / 1e6f else abs(ua) / 1e3f // µA na maioria, mA em alguns
        return Bat(if (lvl < 0) -1 else lvl * 100 / scale, temp, amps * mv / 1000f,
            st == BatteryManager.BATTERY_STATUS_CHARGING)
    }

    fun sh(cmd: String): String = try {
        val p = ProcessBuilder("/system/bin/sh", "-c", cmd).redirectErrorStream(true).start()
        val s = p.inputStream.bufferedReader().readText()
        p.waitFor(1, TimeUnit.SECONDS)
        p.destroy()
        s
    } catch (e: Exception) { "" }
}
