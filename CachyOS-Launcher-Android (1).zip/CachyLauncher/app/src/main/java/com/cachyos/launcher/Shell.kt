package com.cachyos.launcher

import android.content.Context
import java.io.OutputStream

/** Shell /system/bin/sh persistente (sem root, com o UID do app). Use "su" se o aparelho tiver root. */
class Shell(private val ctx: Context, private val onOut: (String) -> Unit) {
    private var proc: Process? = null
    private var stdin: OutputStream? = null

    @Synchronized
    fun start() {
        stop()
        val pb = ProcessBuilder("/system/bin/sh").directory(ctx.filesDir).redirectErrorStream(true)
        pb.environment().apply {
            put("HOME", ctx.filesDir.path)
            put("TMPDIR", ctx.cacheDir.path)
            put("TERM", "dumb")
            put("PATH", (System.getenv("PATH") ?: "") + ":/system/bin:/system/xbin:/vendor/bin")
        }
        val p = pb.start()
        proc = p
        stdin = p.outputStream
        Thread {
            val r = p.inputStream.reader()
            val buf = CharArray(4096)
            while (true) {
                val n = try { r.read(buf) } catch (e: Exception) { -1 }
                if (n < 0) break
                onOut(String(buf, 0, n))
            }
            if (proc === p) onOut("\n[shell encerrado, digite restart]\n")
        }.apply { isDaemon = true }.start()
    }

    @Synchronized
    fun write(s: String) {
        if (proc == null) start()
        try { stdin?.write(s.toByteArray()); stdin?.flush() } catch (_: Exception) {}
    }

    @Synchronized
    fun stop() {
        proc?.destroy()
        proc = null
        stdin = null
    }
}
