package com.cachyos.launcher

import android.content.Context
import android.graphics.Bitmap
import android.webkit.WebResourceResponse
import androidx.core.graphics.drawable.toBitmap
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentHashMap

/** Serve https://appassets.androidplatform.net/icon/<pacote>.png com o ícone real do app. */
class IconHandler(private val c: Context) : WebViewAssetLoader.PathHandler {
    private val cache = ConcurrentHashMap<String, ByteArray>()

    override fun handle(path: String): WebResourceResponse? {
        val pkg = path.removeSuffix(".png")
        val bytes = cache.getOrPut(pkg) {
            try {
                val bm = c.packageManager.getApplicationIcon(pkg).toBitmap(96, 96)
                val o = ByteArrayOutputStream()
                bm.compress(Bitmap.CompressFormat.PNG, 100, o)
                o.toByteArray()
            } catch (e: Exception) {
                return null
            }
        }
        return WebResourceResponse("image/png", null, ByteArrayInputStream(bytes))
    }
}
