/* Liga o "CachyOS" simulado ao Android de verdade: apps reais, terminal real, overlay MangoHud-like. */
(()=>{
'use strict';
const raw=window.Android; if(!raw||!raw.init)return;
const T=raw.init();
const A=new Proxy({},{get:(_,m)=>(...a)=>raw[m](T,...a)});
const J=(s,d)=>{try{return JSON.parse(s)}catch(e){return d}};
const esc=s=>String(s).replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
const toast=t=>{const d=el('<div style="position:absolute;left:50%;bottom:72px;transform:translateX(-50%);background:var(--tb);border:1px solid var(--line);padding:8px 14px;border-radius:12px;z-index:100000;max-width:90%;text-align:center;backdrop-filter:blur(14px)"></div>');d.textContent=t;$('#desk').append(d);setTimeout(()=>d.remove(),3500)};
const myGames=()=>new Set(store('myGames')||[]);
const isGame=a=>a.g||myGames().has(a.p);
const iconImg=p=>`<img src="/icon/${esc(p)}.png" alt="" loading="lazy" style="width:1em;height:1em;border-radius:22%;display:block;margin:0 auto">`;
let APPL=[],lastScan=0;

/* ---------- registro dos apps reais no menu / área de trabalho ---------- */
function reg(){
  for(const k of Object.keys(APPS))if(k.startsWith('app:')){delete APPS[k];delete CAT_OF[k]}
  APPL.forEach(a=>{const k='app:'+a.p;APPS[k]={i:iconImg(a.p),t:a.n,s:a.n,w:300,h:300,b(){}};CAT_OF[k]=isGame(a)?'Jogos':'Android'});
  FAV.length=0;FAV.push('andr','games','mh','lch','term','tasks','files','web','set');
  APPL.filter(isGame).slice(0,8).forEach(a=>FAV.push('app:'+a.p));
}
function desk(){
  const h=$('#icons');h.innerHTML='';const coarse=matchMedia('(pointer:coarse)').matches;
  ['andr','games','mh','lch','term','tasks','files','web','set',...APPL.filter(isGame).slice(0,6).map(a=>'app:'+a.p)].forEach(k=>{
    const a=APPS[k];if(!a)return;const b=el('<button class="ic"><b></b><span></span></button>');
    $('b',b).innerHTML=a.i;$('span',b).textContent=a.s||a.t;
    const go=()=>open(k);b.addEventListener(coarse?'click':'dblclick',go);b.addEventListener('keydown',e=>{if(e.key==='Enter')go()});h.append(b)});
}
function scan(){
  APPL=J(A.apps(),[]).sort((a,b)=>a.n.localeCompare(b.n,'pt-BR'));
  reg();mk();desk();lastScan=Date.now();
}

/* ---------- lançar ---------- */
function launch(p,ov){
  const use=ov===undefined?((store('mhApps')||{})[p]??!!store('mhAll')):ov;
  const r=A.launch(p,!!use);
  if(r==='perm'){toast('Libere “Sobrepor a outros apps” para o launcher e tente de novo.');A.askOverlay()}
  else if(r!=='ok')toast(r);
}
const _open=window.open;
window.open=function(id,arg){
  if(typeof id==='string'&&id.startsWith('app:')){launch(id.slice(4));return}
  return _open.call(window,id,arg);
};

/* ---------- janela Apps / Jogos ---------- */
function appsWin(b,w,mode){
  b.innerHTML=`<div class="pad" style="height:auto"><div class="row"><input class="q" placeholder="${mode==='games'?'Pesquisar jogos...':'Pesquisar apps...'}" aria-label="Pesquisar"><button class="btn g rf" title="Atualizar lista">⟳</button><button class="btn g hm" title="Trocar de launcher">🏠</button><button class="btn g as" title="Ajustes do Android">⚙</button></div>
  <label class="sr2"><span>Overlay MangoHud em todos os lançamentos<small>Escolha as métricas no app MangoHud</small></span><span class="sw2"><input type="checkbox" class="all"><i></i></span></label>
  <div class="sheet"></div><div class="ag"></div></div>`;
  const g=$('.ag',b),sh=$('.sheet',b),q=$('.q',b),all=$('.all',b);
  all.checked=!!store('mhAll');all.onchange=()=>store('mhAll',all.checked);
  $('.rf',b).onclick=()=>{scan();list();toast('Lista atualizada')};
  $('.hm',b).onclick=()=>open('lch');
  $('.as',b).onclick=()=>A.settings();
  const sheet=a=>{
    const pa=store('mhApps')||{},gmk=myGames().has(a.p);
    sh.innerHTML=`<div class="card"><span style="font-size:44px;line-height:1"></span><div style="flex:1;min-width:0"><b></b><br><small></small></div><button class="btn g cl" aria-label="Fechar">✕</button></div>
    <div class="row"><button class="btn go">▶ Iniciar</button><button class="btn mh">▶ Com MangoHud</button></div>
    <div class="row" style="margin:6px 0"><button class="btn g gk"></button><button class="btn g inf">Info</button><button class="btn r un">Desinstalar</button></div>
    <label class="sr2"><span>Sempre com overlay neste app</span><span class="sw2"><input type="checkbox" class="pa"><i></i></span></label>`;
    $('.card>span',sh).innerHTML=iconImg(a.p);$('.card b',sh).textContent=a.n;$('.card small',sh).textContent=a.p;
    $('.cl',sh).onclick=()=>{sh.innerHTML=''};
    $('.go',sh).onclick=()=>launch(a.p,false);
    $('.mh',sh).onclick=()=>launch(a.p,true);
    $('.inf',sh).onclick=()=>A.appInfo(a.p);
    $('.un',sh).onclick=()=>A.uninstall(a.p);
    const gk=$('.gk',sh);if(a.g){gk.textContent='🎮 Detectado como jogo';gk.disabled=true}else{
      gk.textContent=gmk?'🎮 Desmarcar jogo':'🎮 Marcar como jogo';
      gk.onclick=()=>{const s=myGames();s.has(a.p)?s.delete(a.p):s.add(a.p);store('myGames',[...s]);reg();mk();desk();list();sheet(a)}}
    const pc=$('.pa',sh);pc.checked=!!pa[a.p];pc.onchange=()=>{const m=store('mhApps')||{};m[a.p]=pc.checked;store('mhApps',m)};
  };
  const list=()=>{
    const t=q.value.trim().toLowerCase();g.innerHTML='';
    const L=APPL.filter(a=>(mode!=='games'||isGame(a))&&a.n.toLowerCase().includes(t));
    if(!L.length){g.textContent=mode==='games'&&!t?'Nenhum jogo detectado. Em “Apps”, toque num app e use “Marcar como jogo”.':'Nada encontrado.';return}
    L.forEach(a=>{const d=el('<div class="at"><button class="ab"><span style="font-size:48px;line-height:1"></span><span></span></button></div>');
      const[s1,s2]=d.querySelectorAll('.ab>span');s1.innerHTML=iconImg(a.p);s2.textContent=a.n;$('.ab',d).onclick=()=>sheet(a);g.append(d)});
  };
  q.oninput=list;list();
}

/* ---------- janela MangoHud ---------- */
function mhWin(b,w){
  const c={fps:true,cpu:true,gpu:true,ram:true,bat:true,pos:'tl',size:12,...J(A.cfgGet(),{})};
  const tg=(k,l,s)=>`<label class="sr2"><span>${l}<small>${s}</small></span><span class="sw2"><input type="checkbox" data-k="${k}" ${c[k]?'checked':''}><i></i></span></label>`;
  b.innerHTML=`<div class="sgc" style="height:100%"><h3>MangoHud (overlay)</h3>
  <div class="card"><div style="flex:1"><b class="ps"></b><br><small>Precisa da permissão “Sobrepor a outros apps”.</small></div><button class="btn pm">Conceder</button></div>
  ${tg('fps','FPS e tempo de quadro','FPS real exige a permissão DUMP via adb (abaixo). Sem ela mostra a taxa da tela.')}
  ${tg('cpu','Clock da CPU','Maior frequência entre os núcleos')}
  ${tg('gpu','Uso da GPU','Só aparece em aparelhos que liberam a leitura')}
  ${tg('ram','Memória RAM','Usada / total')}
  ${tg('bat','Bateria','Nível, temperatura e potência')}
  <label class="sr2"><span>Posição</span><select data-k="pos"><option value="tl">Topo esquerdo</option><option value="tr">Topo direito</option></select></label>
  <label class="sr2"><span>Tamanho do texto</span><select data-k="size">${[10,12,14,16,20].map(n=>`<option>${n}</option>`).join('')}</select></label>
  <div class="row" style="margin-top:12px"><button class="btn tst">Testar (6 s)</button><button class="btn g off">Desligar overlay</button></div>
  <p><small>O MangoHud de verdade é uma camada Vulkan/OpenGL do Linux e não roda em jogos Android. Este overlay mostra métricas parecidas por cima de qualquer app. Para FPS real do jogo, conecte ao PC e rode:<br><code>adb shell pm grant com.cachyos.launcher android.permission.DUMP</code><br>Nem todo aparelho permite.</small></p></div>`;
  $('[data-k=pos]',b).value=c.pos;$('[data-k=size]',b).value=String(c.size);
  const ps=()=>{const ok=A.canOverlay();$('.ps',b).textContent=ok?'Permissão concedida ✓':'Permissão pendente';$('.pm',b).style.display=ok?'none':''};ps();
  $('.pm',b).onclick=()=>A.askOverlay();
  const onvis=()=>{if(!document.hidden)ps()};document.addEventListener('visibilitychange',onvis);
  const oc=w.onclose;w.onclose=()=>{document.removeEventListener('visibilitychange',onvis);oc&&oc()};
  const save=()=>{b.querySelectorAll('[data-k]').forEach(i=>{const k=i.dataset.k;c[k]=i.type==='checkbox'?i.checked:k==='size'?+i.value:i.value});A.cfgSet(JSON.stringify(c))};
  b.querySelectorAll('[data-k]').forEach(i=>i.onchange=save);
  $('.tst',b).onclick=()=>{if(!A.canOverlay()){toast('Conceda a permissão primeiro.');A.askOverlay();return}A.overlay(true,'');setTimeout(()=>A.overlay(false,''),6000)};
  $('.off',b).onclick=()=>A.overlay(false,'');
}

/* ---------- terminal real ---------- */
const HELP=`Terminal Android (sh, sem root). Comandos do launcher:
  apps [filtro]          lista apps instalados (pacote e nome)
  launch <app>           abre um app
  mangohud <app>         abre o app com o overlay de desempenho
  history                mostra os últimos comandos
  fastfetch | neofetch   informações do sistema (estilo CachyOS)
  btop | htop            monitor ao vivo (q sai)
  pacman/paru/yay        -Syu, -S, -Rns, -Q, -Ss (simulados, nada é baixado)
  cachy-update, cachyos-rate-mirrors, btw
  restart                reinicia o shell
  clear                  limpa a tela
Atalhos: Tab completa, ↑/↓ histórico, Ctrl+C (ou ^C) interrompe, Ctrl+L limpa.
Aliases: ll, la, top (uma amostra), info.
Todo o resto vai para o shell: ls, cd, cat, getprop, pm list packages, am start, dumpsys, ...
Programas que ocupam a tela inteira (vi, nano) não funcionam.
Com root, digite su.
`;
const LOGO=[
"           .-------------------------:",
"          .+=========================.",
"         :++===++==================-       :++-",
"        :*++====+++++=============-        .==:",
"       -*+++=====+***++==========:",
"      =*++++========------------:",
"     =*+++++=====-                    ...",
"   .+*+++++=-===:                    .=+++=:",
"  :++++=====-==:                     -*****+",
" :++========-=.                      .=+**+.",
".+==========-.                          .",
" :+++++++====-                                .--==-.",
"  :++==========.                             :+++++++:",
"   .-===========.                            =*****+*+",
"    .-===========:                           .+*****+:",
"      -=======++++:::::::::::::::::::::::::-:  .---:",
"       :======++++====+++++++++++++++++++++++++++=",
"        :=====+++==========+++++++++++++++++++-",
"         .====++==============++++++++++++++-",
"          .===+==================+++++++++++:",
"           .-=======================+++++++:",
"             :::::::::::::::::::::::::-:."];
const PAL=['#2b2f36','#ff6b6b','#5fd38d','#f2c94c','#6aa9ff','#c792ea','#4dd0e1','#d6e2ff','#6b7280','#ff8a8a','#7ee8a8','#ffe083','#8dbcff','#dcb0ff','#7fe3ee','#ffffff'];
(()=>{const s=document.createElement('style');s.textContent='.rt .o{white-space:pre-wrap;word-break:break-all;user-select:text}.rt .in{align-items:center}.rt .p{white-space:nowrap;max-width:62%;overflow:hidden;text-overflow:ellipsis;flex:none}.rt .qk{position:sticky;bottom:0;display:flex;gap:6px;padding:6px 0 4px;margin-top:6px;background:inherit;border-top:1px solid rgba(255,255,255,.1)}.rt .qk button{flex:1;min-width:0;background:rgba(255,255,255,.09);color:inherit;border:0;border-radius:8px;padding:9px 2px;font:inherit;cursor:pointer}.rt .qk button:active{background:rgba(25,211,182,.4)}.rt input{font-size:15px}.rt .d{opacity:.55}.rt .bt{margin:0;white-space:pre;font:inherit;line-height:1.25;overflow:hidden}.rt .btq{margin-top:8px;padding:9px 18px;border:0;border-radius:8px;background:rgba(255,255,255,.1);color:inherit;font:inherit;cursor:pointer}';document.head.append(s)})();
function realTerm(b,w){
  b.classList.add('term','rt');
  b.innerHTML='<div class="o"></div><div class="in"><span class="p"></span><input autocapitalize="off" autocomplete="off" autocorrect="off" spellcheck="false" enterkeyhint="send" aria-label="Comando"></div><div class="qk"></div>';
  const o=$('.o',b),inp=$('input',b),pr=$('.p',b),qk=$('.qk',b);
  const LOC=['help','clear','apps','launch','mangohud','restart','history'];
  const INFO='echo "$(getprop ro.product.manufacturer) $(getprop ro.product.model)"; echo "Android $(getprop ro.build.version.release) (API $(getprop ro.build.version.sdk))"; uname -sr; echo "ABI: $(getprop ro.product.cpu.abi)"';
  const ALIAS={ll:'ls -la',la:'ls -a',cls:'clear',top:'top -b -n 1',info:INFO};
  const MARK="printf '\\001%s|%s|%s\\001' \"$?\" \"$PWD\" \"$HOME\"\n";
  let H=(store('termHist')||[]).slice(-100),hi=H.length;
  let cwd='',home='',busy=false,dead=false,pend='',cap=null,lastNL=true,sty={fg:null,b:0};
  const PAL_=['#2b2f36','#ff6b6b','#5fd38d','#f2c94c','#6aa9ff','#c792ea','#4dd0e1','#d6e2ff','#6b7280','#ff8a8a','#7ee8a8','#ffe083','#8dbcff','#dcb0ff','#7fe3ee','#ffffff'];
  const near=()=>b.scrollHeight-b.scrollTop-b.clientHeight<90;
  const css=()=>(sty.fg?'color:'+sty.fg+';':'')+(sty.b?'font-weight:700;':'');
  const add=(s,cls,style)=>{if(!s)return;const sp=document.createElement('span');if(cls)sp.className=cls;if(style)sp.style.cssText=style;sp.textContent=s;o.append(sp);lastNL=s.endsWith('\n')};
  const trim=()=>{while(o.childNodes.length>3000)o.firstChild.remove()};
  const put=(s,cls)=>{const st=near();add(s,cls);trim();if(st)b.scrollTop=b.scrollHeight};
  const sgr=p=>{const c=p===''?[0]:p.split(';').map(Number);for(let i=0;i<c.length;i++){const n=c[i];
    if(n===0){sty.fg=null;sty.b=0}else if(n===1)sty.b=1;else if(n===22)sty.b=0;else if(n===39)sty.fg=null;
    else if(n>=30&&n<=37)sty.fg=PAL[n-30];else if(n>=90&&n<=97)sty.fg=PAL[n-82];
    else if(n===38&&c[i+1]===5){const k=c[i+2];if(k<16)sty.fg=PAL[k];i+=2}else if(n===38&&c[i+1]===2)i+=4}};
  const styled=s=>{s=s.replace(/\r\n/g,'\n').replace(/\r/g,'');const re=/\x1b\[([0-9;?]*)([A-Za-z])/g;let last=0,m;
    while((m=re.exec(s))){add(s.slice(last,m.index),'',css());if(m[2]==='m'&&m[1][0]!=='?')sgr(m[1]);last=re.lastIndex}
    add(s.slice(last),'',css())};
  const shortCwd=()=>{let d=cwd||'~';if(home&&(d===home||d.startsWith(home+'/')))d='~'+d.slice(home.length);return 'user@cachyos:'+d+' $'};
  const setPrompt=()=>{pr.textContent=shortCwd();pr.classList.toggle('d',busy)};
  const done=body=>{const p=body.split('|');busy=false;if(!lastNL)add('\n');cwd=p[1]||cwd;home=p[2]||home;
    if(p[0]&&p[0]!=='0'&&sentUser){add('[código '+p[0]+']\n','e')}sentUser=false;setPrompt()};
  let sentUser=false;
  const feed=chunk=>{const st=near();
    if(chunk.indexOf('[shell encerrado')>=0){dead=true;busy=false}
    pend+=chunk;
    for(;;){const i=pend.search(/[\x01\x02]/);
      if(i<0){styled(pend);pend='';break}
      styled(pend.slice(0,i));const open=pend[i],close=open==='\x01'?'\x01':'\x03';
      const j=pend.indexOf(close,i+1);
      if(j<0){pend=pend.slice(i);break}
      const body=pend.slice(i+1,j);pend=pend.slice(j+1);
      if(open==='\x01')done(body);else if(cap){const f=cap;cap=null;f(body)}}
    trim();setPrompt();if(st)b.scrollTop=b.scrollHeight};
  window.__shellOut=feed;
  const prime=()=>setTimeout(()=>A.shellWrite(MARK),250);
  put('Terminal do CachyOS Launcher. Digite help.\n');
  A.shellStart();prime();setPrompt();
  w.onclose=()=>{A.shellStop();window.__shellOut=null};
  const find=n=>{n=n.toLowerCase();return APPL.find(a=>a.p===n)||APPL.find(a=>a.n.toLowerCase()===n)||APPL.find(a=>a.n.toLowerCase().includes(n)||a.p.includes(n))};
  const go=(a,ov)=>{const n=a.join(' ');if(!n){put('uso: '+(ov?'mangohud':'launch')+' <pacote ou nome do app>\n','e');return}
    const x=find(n);if(!x){put('app não encontrado: '+n+'\n','e');return}
    launch(x.p,ov);put((ov?'abrindo com overlay: ':'abrindo: ')+x.n+'\n')};
  const intr=()=>{put('^C\n','e');A.shellStart();busy=false;dead=false;pend='';cap=null;sty={fg:null,b:0};prime();setPrompt()};
  const local={
    help:()=>put(HELP),
    clear:()=>{o.innerHTML=''},
    apps:a=>{const t=(a[0]||'').toLowerCase();put(APPL.filter(x=>!t||x.n.toLowerCase().includes(t)||x.p.includes(t)).map(x=>x.p+'  '+x.n).join('\n')+'\n')},
    launch:a=>go(a,false),
    mangohud:a=>go(a,true),
    history:()=>put(H.map((x,i)=>(i+1)+'  '+x).join('\n')+'\n'),
    restart:()=>{put('[shell reiniciado]\n','p');A.shellStart();busy=false;dead=false;pend='';cap=null;prime()}
  };
  const run=l=>{if(dead){A.shellStart();dead=false;busy=false}
    if(busy){A.shellWrite(l+'\n');return}
    busy=true;sentUser=true;setPrompt();A.shellWrite(l+'\n'+MARK)};
  const submit=()=>{const raw=inp.value;inp.value='';
    put((busy?'':shortCwd()+' ')+raw+'\n','p');
    const l=raw.trim();if(!l){if(busy)run(raw);return}
    if(!busy&&H[H.length-1]!==l){H.push(l);if(H.length>100)H.shift();store('termHist',H)}
    hi=H.length;
    if(busy){run(raw);return}
    let tk=l.split(/\s+/);if(tk[0]==='sudo'&&tk.length>1){tk.shift();if(!local[tk[0]])put('(sem root: rodando sem sudo)\n','d')}
    if(local[tk[0]]){local[tk[0]](tk.slice(1));return}
    if(ALIAS[tk[0]]){run(ALIAS[tk[0]]+(tk.length>1&&!/^(INFO)$/.test(tk[0])&&ALIAS[tk[0]].indexOf(';')<0?' '+tk.slice(1).join(' '):''));return}
    run(tk.join(' '))};
  const histMove=d=>{if(!H.length)return;hi=Math.max(0,Math.min(H.length,hi+d));inp.value=H[hi]||'';inp.setSelectionRange(inp.value.length,inp.value.length)};
  const common=a=>a.reduce((p,s)=>{let i=0;while(i<p.length&&i<s.length&&p[i]===s[i])i++;return p.slice(0,i)},a[0]||'');
  const ask=cmd=>new Promise(res=>{if(busy||dead){res('');return}cap=res;A.shellWrite("printf '\\002'; "+cmd+"; printf '\\003'\n");setTimeout(()=>{if(cap===res){cap=null;res('')}},1500)});
  const tab=async()=>{const v=inp.value,m=v.match(/(\S*)$/),tok=m[1],before=v.slice(0,v.length-tok.length);
    const first=!/\S\s/.test(v)&&before.trim()==='';
    let list=[];
    if(first&&tok&&!/[\/~.]/.test(tok[0])&&tok.indexOf('/')<0)list=[...LOC,...Object.keys(ALIAS)].filter(c=>c.startsWith(tok));
    if(!list.length){if(!/^[A-Za-z0-9_.\/~@%+=:,-]*$/.test(tok))return;
      const r=await ask('ls -1dp -- '+tok+'* 2>/dev/null');list=r.split('\n').filter(Boolean)}
    if(!list.length)return;
    if(list.length===1){const x=list[0];inp.value=before+x+(x.endsWith('/')||first&&false?'':' ');return}
    const c=common(list);if(c.length>tok.length)inp.value=before+c;
    put(shortCwd()+' '+v+'\n','p');put(list.map(x=>x.split('/').filter(Boolean).pop()+(x.endsWith('/')?'/':'')).join('   ')+'\n','d')};
  /* ---- CachyOS: fastfetch, btop, pacman (simulado) ---- */
  const charW=(()=>{const m=document.createElement('span');m.style.cssText='position:absolute;visibility:hidden;white-space:pre';m.textContent='0'.repeat(20);o.append(m);const x=m.getBoundingClientRect().width/20;m.remove();return x||7.8})();
  const colsN=()=>Math.max(30,Math.floor((b.clientWidth-20)/charW));
  const pp=parts=>{const st=near();parts.forEach(p=>add(p[0],'',p[1]||''));add('\n');trim();if(st)b.scrollTop=b.scrollHeight};
  const seq=(L,ms=380)=>new Promise(r=>{let i=0;const t=setInterval(()=>{put(L[i++]+'\n');if(i>=L.length){clearInterval(t);r()}},ms)});
  const GB=x=>(x/1073741824).toFixed(1),TC='#19d3b6';
  const logoSegs=l=>{const out=[];let cur=null,run='';for(const ch of l){const c=ch==='*'||ch==='+'?TC:ch==='='?'#12a58f':ch===' '?cur:'#0e7c6c';if(c!==cur&&run){out.push([run,'color:'+cur]);run=''}cur=c||TC;run+=ch}if(run)out.push([run,'color:'+cur]);return out};
  const FFCMD='g(){ echo "$(getprop "$1" 2>/dev/null)"; }; echo "$(getprop ro.product.manufacturer 2>/dev/null) $(getprop ro.product.model 2>/dev/null)"; echo "$(uname -sr 2>/dev/null)"; echo "$(cut -d. -f1 /proc/uptime 2>/dev/null)"; echo "$(pm list packages 2>/dev/null | wc -l)"; g ro.build.version.release; g ro.build.version.sdk; g ro.soc.model; g ro.board.platform; echo "$(nproc 2>/dev/null)"; echo "$(df -k /data 2>/dev/null | tail -1)"; g ro.hardware.egl; g persist.sys.locale';
  const fastfetch=async()=>{
    const raw=await ask(FFCMD);if(!raw){put('fastfetch: shell ocupado, tente de novo.\n','e');return}
    const r=raw.split('\n'),s=J(A.sysinfo(),{})||{},t=x=>(x||'').trim();
    const up=parseInt(r[2])||0,dd=Math.floor(up/86400),hh=Math.floor(up%86400/3600),mm=Math.floor(up%3600/60);
    const upS=[dd?dd+(dd>1?' dias':' dia'):'',hh?hh+(hh>1?' horas':' hora'):'',mm+' min'].filter(Boolean).join(', ');
    const df=t(r[9]).split(/\s+/),dTot=+df[1]*1024,dUsed=+df[2]*1024;
    const mhz=Math.max(0,...(s.cpu||[0])),soc=t(r[6])||t(r[7])||'ARM',cores=t(r[8])||(s.cpu||[]).length;
    const used=(s.ramT||0)-(s.ramA||0),pc=s.ramT?Math.round(used/s.ramT*100):0;
    let pm=t(r[3]);let pmN=pk&&pk.length;
    const info=[
      ['OS','CachyOS Linux (simulado) sobre Android '+t(r[4])+' (API '+t(r[5])+')'],
      ['Host',t(r[0])||'Android'],['Kernel',t(r[1])],['Uptime',upS],
      ['Packages',pm+' (apps), '+pmN+' (pacman, simulado)'],['Shell','sh (CachyOS Launcher)'],
      ['Display',Math.round(screen.width*devicePixelRatio)+'x'+Math.round(screen.height*devicePixelRatio)],
      ['DE',(sysi&&sysi.de||'KDE Plasma')+' (simulado)'],['WM','KWin (simulado)'],['Terminal','CachyOS Launcher'],
      ['CPU',soc+' ('+cores+')'+(mhz>0?' @ '+(mhz/1000).toFixed(2)+' GHz':'')],
      ['GPU',s.gpu>=0?(t(r[10])||'GPU')+' ('+s.gpu+'%)':(t(r[10])||'indisponível neste aparelho')],
      ['Memory',s.ramT?GB(used)+' GiB / '+GB(s.ramT)+' GiB ('+pc+'%)':'indisponível'],
      ['Disk (/data)',dTot?GB(dUsed)+' GiB / '+GB(dTot)+' GiB ('+Math.round(dUsed/dTot*100)+'%)':'indisponível'],
      ['Battery',s.bat>=0?s.bat+'%'+(s.chg?' [carregando]':''):'indisponível'],['Locale',t(r[11])||navigator.language]];
    const L=LOGO,LW=Math.max(...L.map(x=>x.length)),side=colsN()>=LW+38;
    const infoLines=[[['user','color:'+TC+';font-weight:700'],['@','' ],['cachyos','color:'+TC+';font-weight:700']],[['-'.repeat(12),'']],
      ...info.map(([k,v])=>[[k+': ','color:'+TC+';font-weight:700'],[v,'']])];
    const blocks=[[0,1,2,3,4,5,6,7],[8,9,10,11,12,13,14,15]].map(row=>row.map(i=>['███',"color:"+PAL[i]]));
    if(side){const n=Math.max(L.length,infoLines.length+3);
      for(let i=0;i<n;i++){const lg=L[i]!==undefined?logoSegs(L[i].padEnd(LW)):[[' '.repeat(LW),'']];
        const inf=i<infoLines.length?infoLines[i]:(i===infoLines.length+1?blocks[0]:i===infoLines.length+2?blocks[1]:[]);
        pp([...lg,['   ',''],...inf])}}
    else{const fs=Math.max(5,Math.min(13,Math.floor(13*(colsN()-1)/LW*10)/10)),lb=document.createElement('div');lb.style.cssText='white-space:pre;line-height:1.1;font-size:'+fs+'px';
      L.forEach(l=>{logoSegs(l).forEach(([t,c])=>{const sp=document.createElement('span');sp.style.cssText=c;sp.textContent=t;lb.append(sp)});lb.append('\n')});o.append(lb);lastNL=true;
      infoLines.forEach(l=>pp(l));pp(blocks[0]);pp(blocks[1])}
    put('\n')};
  /* btop (frequência, RAM, bateria; o Android não libera uso de CPU por núcleo/processo para apps) */
  let bt=null;
  const btop=()=>{if(bt)return;
    const pre=document.createElement('pre');pre.className='bt';const q=document.createElement('button');q.type='button';q.className='btq';q.textContent='q  sair';
    [o,$('.in',b),qk].forEach(e=>e.style.display='none');b.append(pre,q);
    const maxf={};let procs=[],tick=0,stop=false;
    const esc2=s=>s.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
    const col=p=>p<50?'#5fd38d':p<80?'#f2c94c':'#ff6b6b';
    const bar=(p,w,c)=>{p=Math.max(0,Math.min(100,p));const n=Math.round(w*p/100);return [['█'.repeat(n),c||col(p)],['░'.repeat(w-n),'#3a4048']]};
    const len=segs=>segs.reduce((a,s)=>a+[...s[0]].length,0);
    const box=(title,lines,W)=>{const iw=W-2,out=[];const t=[...title].length;
      out.push([['╭─┤','#6b7280'],[title,'#d6e2ff'],['├'+'─'.repeat(Math.max(0,iw-t-3))+'╮','#6b7280']]);
      lines.forEach(l=>{l=l.map(x=>x.slice());let ex=len(l)-(iw-2);while(ex>0&&l.length){const z=l[l.length-1],cut=Math.min(ex,[...z[0]].length);z[0]=[...z[0]].slice(0,[...z[0]].length-cut).join('');ex-=cut;if(!z[0])l.pop()}const pad=Math.max(0,iw-2-len(l));out.push([['│ ','#6b7280'],...l,[' '.repeat(pad)+' │','#6b7280']])});
      out.push([['╰'+'─'.repeat(iw)+'╯','#6b7280']]);return out};
    const draw=()=>{if(stop)return;const s=J(A.sysinfo(),null)||{};const W=colsN(),L=[];
      const cpu=s.cpu||[],ok=cpu.some(x=>x>0),bw=Math.max(6,W-4-4-1-9-1);
      const cl=[];if(ok)cpu.forEach((f,i)=>{maxf[i]=Math.max(maxf[i]||1,f);cl.push([[('C'+i).padEnd(3),'#7dd3fc'],...bar(f>0?f/maxf[i]*100:0,bw,'#6aa9ff'),[' '+(f>0?String(f).padStart(5)+' MHz':'    – MHz'),'#d6e2ff']])});
      else cl.push([['Android bloqueou a leitura de CPU neste aparelho.','#9aa0a6']]);
      if(s.gpu>=0)cl.push([['GPU','#7dd3fc'],...bar(s.gpu,bw),[' '+String(s.gpu).padStart(4)+' %','#d6e2ff']]);
      box('cpu · frequência',cl,W).forEach(x=>L.push(x));
      const used=(s.ramT||0)-(s.ramA||0),pc=s.ramT?used/s.ramT*100:0,ml=[];
      ml.push([['RAM','#7dd3fc'],[' ',''],...bar(pc,Math.max(6,W-4-4-8)),[' '+Math.round(pc)+'%','#d6e2ff']]);
      ml.push([['Usada '+GB(used)+' GB · Livre '+GB(s.ramA||0)+' GB · Total '+GB(s.ramT||0)+' GB','#9aa0a6']]);
      if(s.bat>=0){ml.push([['BAT','#7dd3fc'],[' ',''],...bar(s.bat,Math.max(6,W-4-4-8),s.bat>30?'#5fd38d':s.bat>15?'#f2c94c':'#ff6b6b'),[' '+s.bat+'%','#d6e2ff']]);
        ml.push([[(s.temp||0).toFixed(1)+' °C · '+(s.w||0).toFixed(1)+' W'+(s.chg?' · carregando':''),'#9aa0a6']])}
      box('mem · bateria',ml,W).forEach(x=>L.push(x));
      const pl=[[['PID'.padEnd(7)+'MEM'.padStart(7)+'  NOME','#7dd3fc']]];
      procs.slice(0,7).forEach(p=>pl.push([[String(p[0]).padEnd(7)+(p[1]/1024).toFixed(0).padStart(5)+'MB  '+p[2].slice(-(W-22)),'#d6e2ff']]));
      if(procs.length===0)pl.push([['(o Android só mostra os processos do próprio app)','#9aa0a6']]);
      box('proc',pl,W).forEach(x=>L.push(x));
      pre.innerHTML=L.map(l=>l.map(([t,c])=>'<span style="color:'+c+'">'+esc2(t)+'</span>').join('')).join('\n')};
    const refreshProcs=async()=>{if(busy||dead)return;const r=await ask("ps -A -o PID,RSS,NAME 2>/dev/null | sed 1d | sort -k2 -n -r | head -7");
      procs=r.split('\n').map(x=>x.trim().split(/\s+/)).filter(x=>x.length>=3&&+x[1]>0).map(x=>[x[0],+x[1],x.slice(2).join(' ')])};
    const quit=()=>{if(stop)return;stop=true;clearInterval(iv);document.removeEventListener('keydown',kd,true);pre.remove();q.remove();
      [o,$('.in',b),qk].forEach(e=>e.style.display='');bt=null;inp.focus();b.scrollTop=b.scrollHeight};
    const kd=e=>{if(e.key==='q'||e.key==='Q'||e.key==='Escape'||(e.ctrlKey&&(e.key==='c'||e.key==='C'))){e.preventDefault();e.stopPropagation();quit()}};
    document.addEventListener('keydown',kd,true);q.addEventListener('click',quit);
    const iv=setInterval(()=>{draw();if(tick++%3===0)refreshProcs()},1500);bt={quit};draw();refreshProcs()};
  /* pacman / paru / yay / cachy-update (simulados: nada é baixado) */
  const upd=()=>seq([':: Sincronizando bancos de dados...',' cachyos-v3, core, extra, multilib',':: Iniciando atualização completa do sistema...','(1/3) atualizando cachyos-keyring','(2/3) atualizando '+((sysi&&sysi.kern)||'linux-cachyos').split(' ')[0],'(3/3) gerando initramfs e atualizando o '+((sysi&&sysi.boot)||'Limine'),'Tudo atualizado. (Simulação: nada foi baixado.)']);
  const pac=(a,aur)=>{const f=a[0]||'-Syu',n=a.slice(1);if(aur)put(':: Procurando também no AUR...\n');
    if(/^-Sy*u$/.test(f))return upd();
    if(f==='-Q')return put(pk.join('\n')+'\n');
    if(f==='-Ss')return put((CAT.filter(c=>c[0].includes(n[0]||'')).map(c=>'extra/'+c[0]+'  '+c[1]).join('\n')||'nada encontrado')+'\n');
    if(/^-Rn?s?$/.test(f)){pk=pk.filter(x=>!n.includes(x));savePk();return put('removido: '+n.join(' ')+' (simulado)\n')}
    if(f==='-S'){if(!n.length)return put('erro: nenhum alvo informado\n','e');const L=[];n.forEach(x=>{if(CAT.some(c=>c[0]===x)){L.push('resolvendo '+x+'...','instalando '+x+'... (simulado)');if(!pk.includes(x))pk.push(x)}else L.push('erro: alvo não encontrado: '+x)});savePk();return seq(L.concat('pronto.'),450)}
    put('uso: pacman -Syu | -S pacote | -Rns pacote | -Q | -Ss termo\n','e')};
  Object.assign(local,{
    fastfetch:()=>fastfetch(),neofetch:()=>fastfetch(),btop:()=>btop(),htop:()=>btop(),
    pacman:a=>pac(a),paru:a=>pac(a,1),yay:a=>pac(a,1),'cachy-update':()=>upd(),
    'cachyos-rate-mirrors':()=>seq(['Testando espelhos...','Melhores espelhos escolhidos (simulado).']),
    btw:()=>put('Eu uso CachyOS, btw. 🐧\n')});
  LOC.push('fastfetch','neofetch','btop','htop','pacman','paru','yay','cachy-update','cachyos-rate-mirrors','btw');
  setTimeout(()=>{if(!dead)fastfetch()},800);
  inp.addEventListener('keydown',e=>{
    if(e.key==='ArrowUp'){histMove(-1);e.preventDefault()}
    else if(e.key==='ArrowDown'){histMove(1);e.preventDefault()}
    else if(e.key==='Tab'){e.preventDefault();tab()}
    else if(e.ctrlKey&&(e.key==='c'||e.key==='C')&&inp.selectionStart===inp.selectionEnd){e.preventDefault();intr()}
    else if(e.ctrlKey&&(e.key==='l'||e.key==='L')){e.preventDefault();local.clear()}
    else if(e.key==='Enter'){e.preventDefault();submit()}
  });
  const ins=t=>{inp.setRangeText(t,inp.selectionStart,inp.selectionEnd,'end');inp.focus()};
  [['Tab',tab],['^C',intr],['↑',()=>histMove(-1)],['↓',()=>histMove(1)],['/','/'],['~','~'],['-','-'],['|','|'],['.','.']].forEach(([t,f])=>{
    const k=document.createElement('button');k.type='button';k.textContent=t;k.setAttribute('aria-label',t);
    k.addEventListener('mousedown',e=>e.preventDefault());
    k.addEventListener('click',()=>{typeof f==='string'?ins(f):f();inp.focus()});qk.append(k)});
  b.addEventListener('click',()=>{if(!getSelection().toString())inp.focus()});setTimeout(()=>inp.focus(),50);
}

/* ---------- trocar de launcher ---------- */
function lchWin(b,w){
  const draw=()=>{
    const L=J(A.launchers(),[]),cur=L.find(x=>x.d);
    b.innerHTML='<div class="pad" style="height:auto"><b>Trocar de launcher</b><small class="cs"></small><div class="row"><button class="btn me">Usar o CachyOS Launcher como padrão</button></div><div class="ls"></div><button class="btn g st">Abrir ajustes de app padrão do Android</button><small>O botão Início sempre vai para o launcher padrão. “Abrir agora” só mostra o outro launcher uma vez, sem trocar o padrão. Para voltar ao do Android de vez, toque em “Usar como padrão” nele.</small></div>';
    $('.cs',b).textContent=cur?'Padrão atual: '+cur.n:'Nenhum padrão definido (o Android pergunta toda vez que você aperta Início).';
    $('.me',b).onclick=()=>A.setDefault();
    $('.st',b).onclick=()=>A.homeSettings();
    const ls=$('.ls',b);
    L.forEach(x=>{
      const d=el('<div class="card"><span style="font-size:40px;line-height:1"></span><div style="flex:1;min-width:0"><b></b><br><small></small></div><div style="display:flex;flex-direction:column;gap:4px"></div></div>');
      $('span',d).innerHTML=iconImg(x.p);
      $('b',d).textContent=x.n+(x.me?' (este app)':'');
      $('small',d).textContent=x.d?'Padrão atual':x.p;
      const col=d.lastElementChild;
      if(!x.me){
        const o=el('<button class="btn g">Abrir agora</button>');o.onclick=()=>{const r=A.openLauncher(x.p);if(r!=='ok')toast(r)};
        col.append(o);
        if(!x.d){const u=el('<button class="btn">Usar como padrão</button>');u.onclick=()=>{toast('Na lista, escolha: '+x.n);A.homeSettings()};col.append(u)}
      }
      ls.append(d);
    });
  };
  draw();
  const onvis=()=>{if(!document.hidden)draw()};document.addEventListener('visibilitychange',onvis);
  w.onclose=()=>document.removeEventListener('visibilitychange',onvis);
}

/* ---------- monitor real ---------- */
function mon(b,w){
  b.innerHTML='<div class="pad" style="height:auto"><b>Monitor do Sistema</b><div class="mm"></div></div>';
  const m=$('.mm',b),gb=x=>(x/1073741824).toFixed(1);
  const bar=p=>`<div class="prog"><i style="width:${Math.max(0,Math.min(100,p))}%"></i></div>`;
  const draw=()=>{const s=J(A.sysinfo(),null);if(!s||!s.ramT)return;
    const used=s.ramT-s.ramA,pct=Math.round(used/s.ramT*100),ok=s.cpu.some(x=>x>0);
    m.innerHTML=`<div class="card" style="display:block"><b>CPU</b><br><small>${ok?s.cpu.map(x=>x>0?(x/1000).toFixed(2):'–').join(' · ')+' GHz por núcleo':'Frequência bloqueada neste aparelho'}</small></div>
    <div class="card" style="display:block"><b>GPU</b><br><small>${s.gpu>=0?s.gpu+'%':'Leitura indisponível neste aparelho'}</small>${s.gpu>=0?bar(s.gpu):''}</div>
    <div class="card" style="display:block"><b>RAM</b> <small>${gb(used)} / ${gb(s.ramT)} GB (${pct}%)</small>${bar(pct)}</div>
    <div class="card" style="display:block"><b>Bateria</b> <small>${s.bat}% · ${s.temp.toFixed(1)} °C · ${s.w.toFixed(1)} W${s.chg?' · carregando':''}</small>${bar(s.bat)}</div>`};
  draw();const t=setInterval(draw,1500);w.onclose=()=>clearInterval(t);
}

/* ---------- ligar tudo ---------- */
Object.assign(APPS.andr,{t:'Apps Android',s:'Apps',w:560,h:540,b:(b,w)=>appsWin(b,w,'all')});
Object.assign(APPS.games,{t:'Jogos',s:'Jogos',w:560,h:540,b:(b,w)=>appsWin(b,w,'games')});
APPS.mh={i:ico('tasks'),t:'MangoHud (overlay)',s:'MangoHud',w:460,h:560,single:1,b:mhWin};
APPS.lch={i:ico('andr'),t:'Trocar launcher',s:'Launcher',w:460,h:540,single:1,b:lchWin};CAT_OF.lch='Sistema';
Object.assign(APPS.term,{t:'Terminal',s:'Terminal',w:560,h:420,b:realTerm});
Object.assign(APPS.tasks,{t:'Monitor do Sistema',s:'Monitor',w:420,h:420,b:mon});
CATS.push(['Android','🤖 Apps Android']);
PINS.length=0;PINS.push('andr','games','mh','lch','term','tasks','set');

/* rodapé do menu: 🔄 atualiza a lista, ⏻ vira ajustes do Android (nada de "desligar" num launcher) */
const mfr=$('[data-s=r]',menu),mfo=$('[data-s=o]',menu);
if(mfr){mfr.title='Atualizar lista de apps';mfr.setAttribute('aria-label','Atualizar lista de apps')}
if(mfo){mfo.textContent='⚙';mfo.title='Ajustes do Android';mfo.setAttribute('aria-label','Ajustes do Android')}
const _mc=menu.onclick;
menu.onclick=e=>{const x=e.target.closest('button');
  if(x&&x.dataset.s==='r'){menu.classList.remove('show');scan();toast('Lista atualizada');return}
  if(x&&x.dataset.s==='o'){menu.classList.remove('show');A.settings();return}
  _mc(e)};

/* botões Início/Voltar vindos do Android */
window.__home=()=>{menu.classList.remove('show');document.querySelectorAll('.win:not(.min):not(.closing)').forEach(x=>minim(x))};
window.__back=()=>{
  if(menu.classList.contains('show')){menu.classList.remove('show');return}
  const w=[...document.querySelectorAll('.win:not(.min):not(.closing)')].sort((a,b)=>(+b.style.zIndex||0)-(+a.style.zIndex||0))[0];
  if(w&&w.close)w.close();
};
/* pacotes novos/removidos: reescaneia ao voltar para o launcher */
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&Date.now()-lastScan>5000)scan()});

scan();renderTasks();
})();
