/* Liga o "CachyOS" simulado ao Android de verdade: apps reais, terminal real, overlay MangoHud-like. */
(()=>{
'use strict';
const raw=window.Android; if(!raw||!raw.init)return;
const T=raw.init();
const A=new Proxy({},{get:(_,m)=>(...a)=>raw[m](T,...a)});
const J=(s,d)=>{try{return JSON.parse(s)}catch(e){return d}};
const esc=s=>String(s).replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
const toast=t=>{const d=el('<div style="position:absolute;left:50%;bottom:72px;transform:translateX(-50%);background:var(--tb);border:1px solid var(--line);padding:8px 14px;border-radius:12px;z-index:100000;max-width:90%;text-align:center;backdrop-filter:blur(14px)"></div>');d.textContent=t;$('#desk').append(d);setTimeout(()=>d.remove(),3500)};
const myGames=()=>new Set(store('myGames')||[]);
const isGame=a=>a.g||myGames().has(a.p);
const iconImg=p=>`<img src="/icon/${esc(p)}.png" alt="" loading="lazy" style="width:1em;height:1em;border-radius:22%;display:block;margin:0 auto">`;
let APPL=[],lastScan=0;

/* ---------- registro dos apps reais no menu / área de trabalho ---------- */
function reg(){
  for(const k of Object.keys(APPS))if(k.startsWith('app:')){delete APPS[k];delete CAT_OF[k]}
  APPL.forEach(a=>{const k='app:'+a.p;APPS[k]={i:iconImg(a.p),t:a.n,s:a.n,w:300,h:300,b(){}};CAT_OF[k]=isGame(a)?'Jogos':'Android'});
  FAV.length=0;FAV.push('andr','games','mh','term','tasks','files','web','set');
  APPL.filter(isGame).slice(0,8).forEach(a=>FAV.push('app:'+a.p));
}
function desk(){
  const h=$('#icons');h.innerHTML='';const coarse=matchMedia('(pointer:coarse)').matches;
  ['andr','games','mh','term','tasks','files','web','set',...APPL.filter(isGame).slice(0,6).map(a=>'app:'+a.p)].forEach(k=>{
    const a=APPS[k];if(!a)return;const b=el('<button class="ic"><b></b><span></span></button>');
    $('b',b).innerHTML=a.i;$('span',b).textContent=a.s||a.t;
    const go=()=>open(k);b.addEventListener(coarse?'click':'dblclick',go);b.addEventListener('keydown',e=>{if(e.key==='Enter')go()});h.append(b)});
}
function scan(){
  APPL=J(A.apps(),[]).sort((a,b)=>a.n.localeCompare(b.n,'pt-BR'));
  reg();mk();desk();lastScan=Date.now();
}

/* ---------- lançar ---------- */
function launch(p,ov){
  const use=ov===undefined?((store('mhApps')||{})[p]??!!store('mhAll')):ov;
  const r=A.launch(p,!!use);
  if(r==='perm'){toast('Libere “Sobrepor a outros apps” para o launcher e tente de novo.');A.askOverlay()}
  else if(r!=='ok')toast(r);
}
const _open=window.open;
window.open=function(id,arg){
  if(typeof id==='string'&&id.startsWith('app:')){launch(id.slice(4));return}
  return _open.call(window,id,arg);
};

/* ---------- janela Apps / Jogos ---------- */
function appsWin(b,w,mode){
  b.innerHTML=`<div class="pad" style="height:auto"><div class="row"><input class="q" placeholder="${mode==='games'?'Pesquisar jogos...':'Pesquisar apps...'}" aria-label="Pesquisar"><button class="btn g rf" title="Atualizar lista">⟳</button><button class="btn g hm" title="Escolher launcher padrão">🏠</button><button class="btn g as" title="Ajustes do Android">⚙</button></div>
  <label class="sr2"><span>Overlay MangoHud em todos os lançamentos<small>Escolha as métricas no app MangoHud</small></span><span class="sw2"><input type="checkbox" class="all"><i></i></span></label>
  <div class="sheet"></div><div class="ag"></div></div>`;
  const g=$('.ag',b),sh=$('.sheet',b),q=$('.q',b),all=$('.all',b);
  all.checked=!!store('mhAll');all.onchange=()=>store('mhAll',all.checked);
  $('.rf',b).onclick=()=>{scan();list();toast('Lista atualizada')};
  $('.hm',b).onclick=()=>A.homeSettings();
  $('.as',b).onclick=()=>A.settings();
  const sheet=a=>{
    const pa=store('mhApps')||{},gmk=myGames().has(a.p);
    sh.innerHTML=`<div class="card"><span style="font-size:44px;line-height:1"></span><div style="flex:1;min-width:0"><b></b><br><small></small></div><button class="btn g cl" aria-label="Fechar">✕</button></div>
    <div class="row"><button class="btn go">▶ Iniciar</button><button class="btn mh">▶ Com MangoHud</button></div>
    <div class="row" style="margin:6px 0"><button class="btn g gk"></button><button class="btn g inf">Info</button><button class="btn r un">Desinstalar</button></div>
    <label class="sr2"><span>Sempre com overlay neste app</span><span class="sw2"><input type="checkbox" class="pa"><i></i></span></label>`;
    $('.card>span',sh).innerHTML=iconImg(a.p);$('.card b',sh).textContent=a.n;$('.card small',sh).textContent=a.p;
    $('.cl',sh).onclick=()=>{sh.innerHTML=''};
    $('.go',sh).onclick=()=>launch(a.p,false);
    $('.mh',sh).onclick=()=>launch(a.p,true);
    $('.inf',sh).onclick=()=>A.appInfo(a.p);
    $('.un',sh).onclick=()=>A.uninstall(a.p);
    const gk=$('.gk',sh);if(a.g){gk.textContent='🎮 Detectado como jogo';gk.disabled=true}else{
      gk.textContent=gmk?'🎮 Desmarcar jogo':'🎮 Marcar como jogo';
      gk.onclick=()=>{const s=myGames();s.has(a.p)?s.delete(a.p):s.add(a.p);store('myGames',[...s]);reg();mk();desk();list();sheet(a)}}
    const pc=$('.pa',sh);pc.checked=!!pa[a.p];pc.onchange=()=>{const m=store('mhApps')||{};m[a.p]=pc.checked;store('mhApps',m)};
  };
  const list=()=>{
    const t=q.value.trim().toLowerCase();g.innerHTML='';
    const L=APPL.filter(a=>(mode!=='games'||isGame(a))&&a.n.toLowerCase().includes(t));
    if(!L.length){g.textContent=mode==='games'&&!t?'Nenhum jogo detectado. Em “Apps”, toque num app e use “Marcar como jogo”.':'Nada encontrado.';return}
    L.forEach(a=>{const d=el('<div class="at"><button class="ab"><span style="font-size:48px;line-height:1"></span><span></span></button></div>');
      const[s1,s2]=d.querySelectorAll('.ab>span');s1.innerHTML=iconImg(a.p);s2.textContent=a.n;$('.ab',d).onclick=()=>sheet(a);g.append(d)});
  };
  q.oninput=list;list();
}

/* ---------- janela MangoHud ---------- */
function mhWin(b,w){
  const c={fps:true,cpu:true,gpu:true,ram:true,bat:true,pos:'tl',size:12,...J(A.cfgGet(),{})};
  const tg=(k,l,s)=>`<label class="sr2"><span>${l}<small>${s}</small></span><span class="sw2"><input type="checkbox" data-k="${k}" ${c[k]?'checked':''}><i></i></span></label>`;
  b.innerHTML=`<div class="sgc" style="height:100%"><h3>MangoHud (overlay)</h3>
  <div class="card"><div style="flex:1"><b class="ps"></b><br><small>Precisa da permissão “Sobrepor a outros apps”.</small></div><button class="btn pm">Conceder</button></div>
  ${tg('fps','FPS e tempo de quadro','FPS real exige a permissão DUMP via adb (abaixo). Sem ela mostra a taxa da tela.')}
  ${tg('cpu','Clock da CPU','Maior frequência entre os núcleos')}
  ${tg('gpu','Uso da GPU','Só aparece em aparelhos que liberam a leitura')}
  ${tg('ram','Memória RAM','Usada / total')}
  ${tg('bat','Bateria','Nível, temperatura e potência')}
  <label class="sr2"><span>Posição</span><select data-k="pos"><option value="tl">Topo esquerdo</option><option value="tr">Topo direito</option></select></label>
  <label class="sr2"><span>Tamanho do texto</span><select data-k="size">${[10,12,14,16,20].map(n=>`<option>${n}</option>`).join('')}</select></label>
  <div class="row" style="margin-top:12px"><button class="btn tst">Testar (6 s)</button><button class="btn g off">Desligar overlay</button></div>
  <p><small>O MangoHud de verdade é uma camada Vulkan/OpenGL do Linux e não roda em jogos Android. Este overlay mostra métricas parecidas por cima de qualquer app. Para FPS real do jogo, conecte ao PC e rode:<br><code>adb shell pm grant com.cachyos.launcher android.permission.DUMP</code><br>Nem todo aparelho permite.</small></p></div>`;
  $('[data-k=pos]',b).value=c.pos;$('[data-k=size]',b).value=String(c.size);
  const ps=()=>{const ok=A.canOverlay();$('.ps',b).textContent=ok?'Permissão concedida ✓':'Permissão pendente';$('.pm',b).style.display=ok?'none':''};ps();
  $('.pm',b).onclick=()=>A.askOverlay();
  const onvis=()=>{if(!document.hidden)ps()};document.addEventListener('visibilitychange',onvis);
  const oc=w.onclose;w.onclose=()=>{document.removeEventListener('visibilitychange',onvis);oc&&oc()};
  const save=()=>{b.querySelectorAll('[data-k]').forEach(i=>{const k=i.dataset.k;c[k]=i.type==='checkbox'?i.checked:k==='size'?+i.value:i.value});A.cfgSet(JSON.stringify(c))};
  b.querySelectorAll('[data-k]').forEach(i=>i.onchange=save);
  $('.tst',b).onclick=()=>{if(!A.canOverlay()){toast('Conceda a permissão primeiro.');A.askOverlay();return}A.overlay(true,'');setTimeout(()=>A.overlay(false,''),6000)};
  $('.off',b).onclick=()=>A.overlay(false,'');
}

/* ---------- terminal real ---------- */
const HELP=`Terminal Android (sh, sem root). Comandos do launcher:
  apps [filtro]          lista apps instalados (pacote e nome)
  launch <app>           abre um app
  mangohud <app>         abre o app com o overlay de desempenho
  restart                reinicia o shell
  clear                  limpa a tela
Todo o resto vai para o shell: ls, cd, cat, getprop, pm list packages, am start, dumpsys, ...
Programas que precisam de tela cheia (top, vi) não funcionam; use "top -n 1".
Com root, digite su.
`;
function realTerm(b,w){
  b.classList.add('term');
  b.innerHTML='<div class="o" style="white-space:pre-wrap;word-break:break-all"></div><div class="in"><span class="p">$</span><input autocapitalize="off" autocomplete="off" autocorrect="off" spellcheck="false" aria-label="Comando"></div>';
  const o=$('.o',b),inp=$('input',b),H=[];let hi=0;
  const put=(s,c)=>{const sp=document.createElement('span');if(c)sp.className=c;sp.textContent=s;o.append(sp);b.scrollTop=b.scrollHeight};
  window.__shellOut=s=>put(s.replace(/\x1b\[[0-9;?]*[A-Za-z]/g,'').replace(/\r/g,''));
  put('Terminal do CachyOS Launcher. Digite help.\n');
  A.shellStart();
  w.onclose=()=>{A.shellStop();window.__shellOut=null};
  const find=n=>{n=n.toLowerCase();return APPL.find(a=>a.p===n)||APPL.find(a=>a.n.toLowerCase()===n)||APPL.find(a=>a.n.toLowerCase().includes(n)||a.p.includes(n))};
  const go=(a,ov)=>{const n=a.join(' ');if(!n){put('uso: '+(ov?'mangohud':'launch')+' <pacote ou nome do app>\n','e');return}
    const x=find(n);if(!x){put('app não encontrado: '+n+'\n','e');return}
    launch(x.p,ov);put((ov?'abrindo com overlay: ':'abrindo: ')+x.n+'\n')};
  const local={
    help:()=>put(HELP),
    clear:()=>{o.innerHTML=''},
    apps:a=>{const t=(a[0]||'').toLowerCase();put(APPL.filter(x=>!t||x.n.toLowerCase().includes(t)||x.p.includes(t)).map(x=>x.p+'  '+x.n).join('\n')+'\n')},
    launch:a=>go(a,false),
    mangohud:a=>go(a,true),
    restart:()=>{A.shellStart();put('[shell reiniciado]\n','p')}
  };
  inp.addEventListener('keydown',e=>{
    if(e.key==='ArrowUp'&&H.length){hi=Math.max(0,hi-1);inp.value=H[hi];e.preventDefault()}
    if(e.key==='ArrowDown'&&H.length){hi=Math.min(H.length,hi+1);inp.value=H[hi]||'';e.preventDefault()}
    if(e.key!=='Enter')return;
    const l=inp.value.trim();inp.value='';if(!l)return;H.push(l);hi=H.length;put('$ '+l+'\n','p');
    const tk=l.split(/\s+/);(local[tk[0]]||(()=>A.shellWrite(l+'\n')))(tk.slice(1));
  });
  b.addEventListener('click',()=>{if(!getSelection().toString())inp.focus()});setTimeout(()=>inp.focus(),50);
}

/* ---------- monitor real ---------- */
function mon(b,w){
  b.innerHTML='<div class="pad" style="height:auto"><b>Monitor do Sistema</b><div class="mm"></div></div>';
  const m=$('.mm',b),gb=x=>(x/1073741824).toFixed(1);
  const bar=p=>`<div class="prog"><i style="width:${Math.max(0,Math.min(100,p))}%"></i></div>`;
  const draw=()=>{const s=J(A.sysinfo(),null);if(!s||!s.ramT)return;
    const used=s.ramT-s.ramA,pct=Math.round(used/s.ramT*100),ok=s.cpu.some(x=>x>0);
    m.innerHTML=`<div class="card" style="display:block"><b>CPU</b><br><small>${ok?s.cpu.map(x=>x>0?(x/1000).toFixed(2):'–').join(' · ')+' GHz por núcleo':'Frequência bloqueada neste aparelho'}</small></div>
    <div class="card" style="display:block"><b>GPU</b><br><small>${s.gpu>=0?s.gpu+'%':'Leitura indisponível neste aparelho'}</small>${s.gpu>=0?bar(s.gpu):''}</div>
    <div class="card" style="display:block"><b>RAM</b> <small>${gb(used)} / ${gb(s.ramT)} GB (${pct}%)</small>${bar(pct)}</div>
    <div class="card" style="display:block"><b>Bateria</b> <small>${s.bat}% · ${s.temp.toFixed(1)} °C · ${s.w.toFixed(1)} W${s.chg?' · carregando':''}</small>${bar(s.bat)}</div>`};
  draw();const t=setInterval(draw,1500);w.onclose=()=>clearInterval(t);
}

/* ---------- ligar tudo ---------- */
Object.assign(APPS.andr,{t:'Apps Android',s:'Apps',w:560,h:540,b:(b,w)=>appsWin(b,w,'all')});
Object.assign(APPS.games,{t:'Jogos',s:'Jogos',w:560,h:540,b:(b,w)=>appsWin(b,w,'games')});
APPS.mh={i:ico('tasks'),t:'MangoHud (overlay)',s:'MangoHud',w:460,h:560,single:1,b:mhWin};
Object.assign(APPS.term,{t:'Terminal',s:'Terminal',w:560,h:420,b:realTerm});
Object.assign(APPS.tasks,{t:'Monitor do Sistema',s:'Monitor',w:420,h:420,b:mon});
CATS.push(['Android','🤖 Apps Android']);
PINS.length=0;PINS.push('andr','games','mh','term','tasks','set');

/* rodapé do menu: 🔄 atualiza a lista, ⏻ vira ajustes do Android (nada de "desligar" num launcher) */
const mfr=$('[data-s=r]',menu),mfo=$('[data-s=o]',menu);
if(mfr){mfr.title='Atualizar lista de apps';mfr.setAttribute('aria-label','Atualizar lista de apps')}
if(mfo){mfo.textContent='⚙';mfo.title='Ajustes do Android';mfo.setAttribute('aria-label','Ajustes do Android')}
const _mc=menu.onclick;
menu.onclick=e=>{const x=e.target.closest('button');
  if(x&&x.dataset.s==='r'){menu.classList.remove('show');scan();toast('Lista atualizada');return}
  if(x&&x.dataset.s==='o'){menu.classList.remove('show');A.settings();return}
  _mc(e)};

/* botões Início/Voltar vindos do Android */
window.__home=()=>{menu.classList.remove('show');document.querySelectorAll('.win:not(.min):not(.closing)').forEach(x=>minim(x))};
window.__back=()=>{
  if(menu.classList.contains('show')){menu.classList.remove('show');return}
  const w=[...document.querySelectorAll('.win:not(.min):not(.closing)')].sort((a,b)=>(+b.style.zIndex||0)-(+a.style.zIndex||0))[0];
  if(w&&w.close)w.close();
};
/* pacotes novos/removidos: reescaneia ao voltar para o launcher */
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&Date.now()-lastScan>5000)scan()});

scan();renderTasks();
})();
